DisplayControl Arduino firmware bundle

Version: 0.2.49
Board: arduino:renesas_uno:nanor4
Image: display_control_firmware.ino.bin

Drop this .zip file onto Flash-Arduino.bat from the portable flasher package.
The flasher verifies manifest.ini and asks before installing an older firmware
version over a newer one.
